====================== What you want to do with your addon! ======================
In case you want to share your addon:

You can upload it to Planet Minecraft or other platform by yourself

For this, you must provide credit to TE+ Renewed original datapack link
=======================================================================================

                                       WARNING!!!

I'm not responsible for any of the bugs in your addon, I make sure to give clear instructions, so
if something isn't tworking, is not my fault! 

However, if you find bugs that are related to TE+ Renewed original datapack, be sure to tell me and I
will check it out.
=======================================================================================

You can contact me through discord: Frektip#4587 






